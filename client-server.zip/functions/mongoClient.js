const { MongoClient } = require('mongodb');
require("dotenv").config();

const mongoUrl = process.env.MONGO_URL;

const connectMongo = async () => {
  try {
    // การเชื่อมต่อ MongoDB โดยไม่ต้องใช้ useNewUrlParser และ useUnifiedTopology
    const client = await MongoClient.connect(mongoUrl);
    const db = client.db(process.env.DB_NAME); // ชื่อฐานข้อมูล
    return { client, db };
  } catch (error) {
    console.error("Error connecting to MongoDB:", error.message);
    throw error;
  }
};

module.exports = { connectMongo };
