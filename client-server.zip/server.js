require("dotenv").config(); // เรียกใช้ dotenv เพื่อโหลด environment variables
const express = require("express");
const http = require("http");
const { connectMongo } = require("./functions/mongoClient");
const { io } = require("socket.io-client");


const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;
const mainServer = process.env.MAIN_SERVER;
const clientName = process.env.CLIENT_NAME;

// เชื่อมต่อกับ Main Server
const socket = io(mainServer);

app.set("view engine", "ejs");
app.set("views", "./views");

app.get("/", (req, res) => {
  const progress = 0; // ค่า progress ที่คุณต้องการแสดงในหน้าจอ
  res.render("index", { progress });
});


socket.on("connect", () => {
  console.log("Connected to Main-Server");

  // ร้องขอข้อมูลจาก Server 1
  socket.emit("request-data", clientName);
});

// รับข้อมูลทีละ batch จาก Server 1
socket.on("data-batch", async ({ data, progress }) => {
  // console.log(
  //   `Received batch of ${data.length} vehicles, Progress: ${progress}%`
  // );

  // เชื่อมต่อกับ MongoDB ของ Server 2
  const { client, db } = await connectMongo();
  const collection = db.collection(process.env.COLLECTION_NAME);

  try {
    // สร้าง array ของ update operations เพื่อใช้ bulkWrite
    const operations = data.map((vehicle) => ({
      updateOne: {
        filter: { _id: vehicle._id },
        update: { $set: vehicle },
        upsert: true, // ถ้าไม่มี _id ตรงกัน ให้ทำการแทรกใหม่
      },
    }));

    // ใช้ bulkWrite เพื่ออัปเดตข้อมูลทั้งหมดในครั้งเดียว
    const result = await collection.bulkWrite(operations);

    console.log(
      JSON.stringify(
        {
          message_upserted: `Upserted ${result.upsertedCount} vehicles`,
          message_matched: `matched ${result.matchedCount} vehicles`,
          messgae_modified: `modified ${result.modifiedCount} vehicles`,
          progress: `${progress}%`,
        },
        null,
        2
      )
    );
  } catch (error) {
    console.error(
      JSON.stringify(
        { message: "Error upserting batch data:", error: error.message },
        null,
        2
      )
    );
  } finally {
    client.close();
  }
});

// เมื่อ Server 1 ส่งข้อมูลทั้งหมดเสร็จ
socket.on("all-data-sent", () => {
  console.log(`All data has been received and saved in ${clientName}`);

  // ปิดการเชื่อมต่อหลังจากรับข้อมูลเสร็จ
  socket.disconnect();
});

// Start the server
server.listen(PORT, () => {
  console.log(`SubServer is running on port ${PORT}`);
});
